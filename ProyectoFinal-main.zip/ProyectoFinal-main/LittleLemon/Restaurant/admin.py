from django.contrib import admin
from .models import Menu, Reservas

# Register your models here.

admin.site.register(Menu)
admin.site.register(Reservas)
